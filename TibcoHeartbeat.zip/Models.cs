using System.Text.Json.Serialization;

namespace TibcoHeartbeat;

public enum ServerType { EMS, BW6, BWCE, HAWK }
public enum HealthStatus { UP, DEGRADED, DOWN, UNKNOWN }
public enum Severity { CRITICAL, ERROR, WARN, INFO, DEBUG }

/// <summary>A monitored TIBCO endpoint. Password is write-only: stored encrypted, never returned.</summary>
public class ServerConfig
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public ServerType Type { get; set; }
    public string Env { get; set; } = "DEV";
    public string Host { get; set; } = "";
    public int Port { get; set; }
    public string Protocol { get; set; } = "tcp";
    public string Username { get; set; } = "";
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Password { get; set; }              // only on input
    [JsonIgnore] public string? ProtectedPassword { get; set; }
    public bool HasPassword => !string.IsNullOrEmpty(ProtectedPassword);
    public string Domain { get; set; } = "";           // BW6
    public string HealthPath { get; set; } = "";       // BWCE (/_ping) or Hawk HTTP
    public int PollSeconds { get; set; } = 30;
    public bool Enabled { get; set; } = true;
    public List<string> Downstream { get; set; } = new();
    public string Notes { get; set; } = "";
}

/// <summary>What gets persisted to servers.json (includes the encrypted password).</summary>
public class StoredServer : ServerConfig
{
    [JsonPropertyName("protectedPassword")]
    public string? StoredSecret { get => ProtectedPassword; set => ProtectedPassword = value; }
}

public record Heartbeat(DateTimeOffset Ts, HealthStatus Status, int? LatencyMs, string Detail);

public class LogEntry
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N")[..12];
    public DateTimeOffset Ts { get; init; } = DateTimeOffset.UtcNow;
    public string? ServerId { get; init; }
    public string ServerName { get; init; } = "collector";
    public Severity Severity { get; init; }
    public string Code { get; init; } = "";
    public string Message { get; init; } = "";
    public bool Acked { get; set; }
}

public record Connection(
    string FromServerId, string FromName, string FromHost, string FromEnv,
    string ToHost, int? ToPort, string? ToName, string ToEnv,
    string Kind, bool Violation, DateTimeOffset SeenAt);

public record EnvRule(string Token, string Env);

/// <summary>Result of one probe run against one server.</summary>
public class ProbeResult
{
    public HealthStatus Status { get; set; } = HealthStatus.UNKNOWN;
    public int? LatencyMs { get; set; }
    public string Detail { get; set; } = "";
    /// <summary>Extra events the probe wants logged (impaired apps, route drops, ...).</summary>
    public List<(Severity Sev, string Code, string Message)> Events { get; } = new();
    /// <summary>Links observed at runtime (EMS clients and routes).</summary>
    public List<(string Host, int? Port, string Kind, bool Inbound)> Observed { get; } = new();
}

public record AckRequest(List<string> Ids);
