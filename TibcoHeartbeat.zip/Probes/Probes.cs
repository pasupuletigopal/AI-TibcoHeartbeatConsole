using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace TibcoHeartbeat.Probes;

public interface IProbe
{
    ServerType Type { get; }
    Task<ProbeResult> CheckAsync(ServerConfig s, string? password, CancellationToken ct);
}

static class ProbeHelpers
{
    public static int DegradedAfterMs = 1500;

    public static async Task<(bool ok, int ms, string? error)> TcpAsync(string host, int port, int timeoutMs, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        using var client = new TcpClient();
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(timeoutMs);
        try { await client.ConnectAsync(host, port, cts.Token); return (true, (int)sw.ElapsedMilliseconds, null); }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { return (false, (int)sw.ElapsedMilliseconds, $"no answer within {timeoutMs / 1000} s"); }
        catch (SocketException ex) { return (false, (int)sw.ElapsedMilliseconds, ex.SocketErrorCode.ToString()); }
    }

    public static void Grade(ProbeResult r, int ms)
    {
        r.LatencyMs = ms;
        r.Status = ms > DegradedAfterMs ? HealthStatus.DEGRADED : HealthStatus.UP;
    }

    public static HttpRequestMessage Get(string url, ServerConfig s, string? password)
    {
        var req = new HttpRequestMessage(HttpMethod.Get, url);
        if (!string.IsNullOrEmpty(s.Username))
            req.Headers.Authorization = new AuthenticationHeaderValue("Basic",
                Convert.ToBase64String(Encoding.UTF8.GetBytes($"{s.Username}:{password}")));
        return req;
    }
}

/// <summary>
/// EMS: TCP liveness always. With the EMS_ADMIN build symbol and TIBCO.EMS.ADMIN.dll referenced,
/// also reads server state, client connections (upstream) and routes (downstream).
/// </summary>
public class EmsProbe : IProbe
{
    public ServerType Type => ServerType.EMS;

    public async Task<ProbeResult> CheckAsync(ServerConfig s, string? password, CancellationToken ct)
    {
        var r = new ProbeResult();
        var (ok, ms, err) = await ProbeHelpers.TcpAsync(s.Host, s.Port, 5000, ct);
        if (!ok) { r.Status = HealthStatus.DOWN; r.Detail = $"cannot reach {s.Protocol}://{s.Host}:{s.Port}: {err}"; return r; }
        ProbeHelpers.Grade(r, ms);
        r.Detail = "listening";
#if EMS_ADMIN
        await Task.Run(() => ReadAdmin(s, password, r), ct);
#endif
        return r;
    }

#if EMS_ADMIN
    // Member names below follow the EMS .NET admin API (TIBCO.EMS.ADMIN). They can differ slightly between
    // EMS versions; if this does not compile, check the Admin, ServerInfo, ConnectionInfo and RouteInfo
    // classes in the reference shipped with your EMS installation.
    static void ReadAdmin(ServerConfig s, string? password, ProbeResult r)
    {
        var url = $"{s.Protocol}://{s.Host}:{s.Port}";
        TIBCO.EMS.ADMIN.Admin? admin = null;
        try
        {
            admin = new TIBCO.EMS.ADMIN.Admin(url, s.Username, password ?? "");
            var info = admin.Info;
            var conns = admin.Connections ?? Array.Empty<TIBCO.EMS.ADMIN.ConnectionInfo>();
            var routes = admin.Routes ?? Array.Empty<TIBCO.EMS.ADMIN.RouteInfo>();
            var down = 0;
            foreach (var c in conns)
                if (!string.IsNullOrEmpty(c.Host)) r.Observed.Add((c.Host, null, $"EMS client ({c.Type})", true));
            foreach (var rt in routes)
            {
                r.Observed.Add((rt.URL ?? rt.Name, null, "EMS route", false));
                if (!rt.Connected) { down++; r.Events.Add((Severity.ERROR, "EMS-ROUTE", $"Route {rt.Name} to {rt.URL} is not connected")); }
            }
            r.Detail = $"{info.State}, {conns.Length} connections, {routes.Length} routes";
            if (down > 0 && r.Status == HealthStatus.UP) r.Status = HealthStatus.DEGRADED;
        }
        catch (Exception ex)
        {
            r.Events.Add((Severity.WARN, "EMS-ADMIN", $"Port is open but the admin API call failed: {ex.Message}"));
            if (r.Status == HealthStatus.UP) r.Status = HealthStatus.DEGRADED;
        }
        finally { try { admin?.Close(); } catch { } }
    }
#endif
}

/// <summary>BW6: bwagent REST API, /bw/v1/browse/appnodes and /bw/v1/browse/applications for a domain.</summary>
public class Bw6Probe(IHttpClientFactory http) : IProbe
{
    public ServerType Type => ServerType.BW6;

    public async Task<ProbeResult> CheckAsync(ServerConfig s, string? password, CancellationToken ct)
    {
        var r = new ProbeResult();
        var baseUrl = $"{s.Protocol}://{s.Host}:{s.Port}/bw/v1/browse";
        var client = http.CreateClient("probe");
        var sw = Stopwatch.StartNew();
        try
        {
            using var nodesResp = await client.SendAsync(ProbeHelpers.Get($"{baseUrl}/appnodes?domain={Uri.EscapeDataString(s.Domain)}", s, password), ct);
            if (!nodesResp.IsSuccessStatusCode)
            {
                r.Status = nodesResp.StatusCode is System.Net.HttpStatusCode.Unauthorized or System.Net.HttpStatusCode.Forbidden ? HealthStatus.DEGRADED : HealthStatus.DOWN;
                r.Detail = $"bwagent returned {(int)nodesResp.StatusCode} {nodesResp.ReasonPhrase}";
                return r;
            }
            ProbeHelpers.Grade(r, (int)sw.ElapsedMilliseconds);
            var nodes = Parse(await nodesResp.Content.ReadAsStringAsync(ct));
            var nodeBad = nodes.Where(n => !Is(n.State, "Running")).ToList();
            foreach (var n in nodeBad) r.Events.Add((Severity.ERROR, "BW-APPNODE", $"AppNode {n.Name} is {n.State}"));

            using var appsResp = await client.SendAsync(ProbeHelpers.Get($"{baseUrl}/applications?domain={Uri.EscapeDataString(s.Domain)}", s, password), ct);
            var apps = appsResp.IsSuccessStatusCode ? Parse(await appsResp.Content.ReadAsStringAsync(ct)) : new();
            var impaired = apps.Where(a => Is(a.State, "Impaired")).ToList();
            var stopped = apps.Where(a => Is(a.State, "Stopped") || Is(a.State, "StartFailed")).ToList();
            foreach (var a in impaired) r.Events.Add((Severity.ERROR, "BW-IMPAIRED", $"Application {a.Name} is Impaired{(a.Where is null ? "" : " on " + a.Where)}"));
            foreach (var a in stopped) r.Events.Add((Severity.WARN, "BW-STOPPED", $"Application {a.Name} is {a.State}"));

            var running = apps.Count(a => Is(a.State, "Running"));
            r.Detail = $"{nodes.Count - nodeBad.Count} of {nodes.Count} AppNodes running, {running} of {apps.Count} applications running" + (impaired.Count > 0 ? $", {impaired.Count} impaired" : "");
            if (nodeBad.Count > 0 || impaired.Count > 0) r.Status = HealthStatus.DEGRADED;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            r.Status = HealthStatus.DOWN;
            r.Detail = $"bwagent at {s.Host}:{s.Port} not responding: {ex.Message}";
        }
        return r;
    }

    static bool Is(string? v, string want) => string.Equals(v, want, StringComparison.OrdinalIgnoreCase);

    record Item(string Name, string? State, string? Where);

    // The response shape varies a little between BW versions; read the common fields defensively.
    static List<Item> Parse(string json)
    {
        var list = new List<Item>();
        using var doc = JsonDocument.Parse(json);
        var arr = doc.RootElement.ValueKind == JsonValueKind.Array ? doc.RootElement
                : doc.RootElement.TryGetProperty("items", out var it) ? it : default;
        if (arr.ValueKind != JsonValueKind.Array) return list;
        foreach (var e in arr.EnumerateArray())
        {
            string? Str(params string[] keys) { foreach (var k in keys) if (e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String) return v.GetString(); return null; }
            list.Add(new Item(Str("name") ?? "?", Str("state", "status"), Str("appNodeName", "appSpaceName")));
        }
        return list;
    }
}

/// <summary>BWCE: GET /_ping on port 7777 (defaults), 200 = up.</summary>
public class BwceProbe(IHttpClientFactory http) : IProbe
{
    public ServerType Type => ServerType.BWCE;

    public async Task<ProbeResult> CheckAsync(ServerConfig s, string? password, CancellationToken ct)
    {
        var r = new ProbeResult();
        var path = string.IsNullOrWhiteSpace(s.HealthPath) ? "/_ping" : s.HealthPath;
        var url = $"{s.Protocol}://{s.Host}:{s.Port}{path}";
        var sw = Stopwatch.StartNew();
        try
        {
            using var resp = await http.CreateClient("probe").SendAsync(ProbeHelpers.Get(url, s, password), ct);
            if (resp.IsSuccessStatusCode) { ProbeHelpers.Grade(r, (int)sw.ElapsedMilliseconds); r.Detail = $"{path} {(int)resp.StatusCode}"; }
            else { r.Status = HealthStatus.DOWN; r.Detail = $"{path} returned {(int)resp.StatusCode}"; }
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            r.Status = HealthStatus.DOWN; r.Detail = $"GET {url} failed: {ex.Message}";
        }
        return r;
    }
}

/// <summary>Hawk: TCP check on the given port, or an HTTP GET when protocol is http/https and a path is set.</summary>
public class HawkProbe(IHttpClientFactory http) : IProbe
{
    public ServerType Type => ServerType.HAWK;

    public async Task<ProbeResult> CheckAsync(ServerConfig s, string? password, CancellationToken ct)
    {
        var r = new ProbeResult();
        if (s.Protocol is "http" or "https")
        {
            var url = $"{s.Protocol}://{s.Host}:{s.Port}{(string.IsNullOrWhiteSpace(s.HealthPath) ? "/" : s.HealthPath)}";
            var sw = Stopwatch.StartNew();
            try
            {
                using var resp = await http.CreateClient("probe").SendAsync(ProbeHelpers.Get(url, s, password), ct);
                if ((int)resp.StatusCode < 500) { ProbeHelpers.Grade(r, (int)sw.ElapsedMilliseconds); r.Detail = $"HTTP {(int)resp.StatusCode}"; }
                else { r.Status = HealthStatus.DOWN; r.Detail = $"HTTP {(int)resp.StatusCode}"; }
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
            { r.Status = HealthStatus.DOWN; r.Detail = $"GET {url} failed: {ex.Message}"; }
            return r;
        }
        var (ok, ms, err) = await ProbeHelpers.TcpAsync(s.Host, s.Port, 5000, ct);
        if (ok) { ProbeHelpers.Grade(r, ms); r.Detail = "port open"; }
        else { r.Status = HealthStatus.DOWN; r.Detail = $"cannot reach {s.Host}:{s.Port}: {err}"; }
        return r;
    }
}
