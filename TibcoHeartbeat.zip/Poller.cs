using System.Collections.Concurrent;
using TibcoHeartbeat.Probes;

namespace TibcoHeartbeat;

/// <summary>Runs each enabled server's probe on its own interval, records heartbeats, turns changes into log lines.</summary>
public class Poller(Store store, IEnumerable<IProbe> probes, ILogger<Poller> log) : BackgroundService
{
    readonly Dictionary<ServerType, IProbe> _probes = probes.ToDictionary(p => p.Type);
    readonly ConcurrentDictionary<string, DateTimeOffset> _nextRun = new();
    readonly ConcurrentDictionary<string, byte> _running = new();
    readonly ConcurrentDictionary<string, byte> _reportedViolations = new();
    readonly ConcurrentDictionary<string, HashSet<string>> _activeEvents = new();

    protected override async Task ExecuteAsync(CancellationToken stop)
    {
        store.Log(null, Severity.INFO, "COLLECTOR", $"Collector started with {store.Servers.Count} servers");
        while (!stop.IsCancellationRequested)
        {
            var now = DateTimeOffset.UtcNow;
            foreach (var s in store.Servers.Where(s => s.Enabled))
            {
                if (_nextRun.TryGetValue(s.Id, out var due) && due > now) continue;
                if (!_running.TryAdd(s.Id, 0)) continue;
                _nextRun[s.Id] = now.AddSeconds(s.PollSeconds);
                _ = Task.Run(async () => { try { await CheckAsync(s.Id, stop); } finally { _running.TryRemove(s.Id, out _); } }, stop);
            }
            await Task.Delay(1000, stop);
        }
    }

    public async Task CheckAsync(string serverId, CancellationToken ct)
    {
        var s = store.Get(serverId);
        if (s is null || !_probes.TryGetValue(s.Type, out var probe)) return;
        var prev = store.Latest(s.Id)?.Status;
        ProbeResult r;
        try { r = await probe.CheckAsync(s, store.DecryptPassword(s), ct); }
        catch (Exception ex)
        {
            log.LogWarning(ex, "Probe failed for {Server}", s.Name);
            r = new ProbeResult { Status = HealthStatus.DOWN, Detail = "probe error: " + ex.Message };
        }
        store.AddHeartbeat(s.Id, new Heartbeat(DateTimeOffset.UtcNow, r.Status, r.LatencyMs, r.Detail));

        if (prev != r.Status)
        {
            switch (r.Status)
            {
                case HealthStatus.DOWN: store.Log(s, Severity.CRITICAL, "HB-DOWN", $"{s.Name} is down: {r.Detail}"); break;
                case HealthStatus.DEGRADED: store.Log(s, Severity.WARN, "HB-DEGRADED", $"{s.Name} degraded: {r.Detail}{(r.LatencyMs is int ms ? $" ({ms} ms)" : "")}"); break;
                case HealthStatus.UP when prev is not null: store.Log(s, Severity.INFO, "HB-RECOVERED", $"{s.Name} healthy again ({r.Detail})"); break;
            }
        }
        // Probe events (impaired app, stopped AppNode, route down) are logged when they appear and when they clear,
        // not on every poll, so the triage queue is not flooded.
        var now = r.Events.Select(e => $"{e.Code}|{e.Message}").ToHashSet();
        var before = _activeEvents.GetValueOrDefault(s.Id) ?? new HashSet<string>();
        foreach (var (sev, code, msg) in r.Events) if (!before.Contains($"{code}|{msg}")) store.Log(s, sev, code, msg);
        foreach (var gone in before.Except(now)) store.Log(s, Severity.INFO, "CLEARED", $"Cleared: {gone.Split('|', 2)[1]}");
        _activeEvents[s.Id] = now;

        BuildConnections(s, r);
    }

    void BuildConnections(ServerConfig s, ProbeResult r)
    {
        var now = DateTimeOffset.UtcNow;
        var list = new List<Connection>();
        var servers = store.Servers;

        Connection Make(string fromId, string fromName, string fromHost, string fromEnv, string toHost, int? toPort, string kind)
        {
            var toEnv = store.EnvOfHost(toHost);
            var toName = servers.FirstOrDefault(x => x.Host.Equals(toHost, StringComparison.OrdinalIgnoreCase))?.Name;
            var viol = fromEnv != "UNKNOWN" && toEnv != "UNKNOWN" && fromEnv != toEnv;
            return new Connection(fromId, fromName, fromHost, fromEnv, toHost, toPort, toName, toEnv, kind, viol, now);
        }

        foreach (var d in s.Downstream)
        {
            var parts = d.Split(':');
            list.Add(Make(s.Id, s.Name, s.Host, s.Env, parts[0], parts.Length > 1 && int.TryParse(parts[1], out var p) ? p : null, "Declared"));
        }
        foreach (var o in r.Observed)
        {
            var host = o.Host.Replace("tcp://", "").Replace("ssl://", "").Split(':')[0];
            if (o.Inbound)
            {   // a client connected to this EMS: link runs client -> EMS
                var fromEnv = store.EnvOfHost(host);
                var from = servers.FirstOrDefault(x => x.Host.Equals(host, StringComparison.OrdinalIgnoreCase));
                var viol = fromEnv != "UNKNOWN" && s.Env != fromEnv;
                list.Add(new Connection(from?.Id ?? s.Id, from?.Name ?? host, host, fromEnv, s.Host, s.Port, s.Name, s.Env, o.Kind + " (observed)", viol, now));
            }
            else list.Add(Make(s.Id, s.Name, s.Host, s.Env, host, o.Port, o.Kind + " (observed)"));
        }
        store.SetConnections(s.Id, list);

        foreach (var c in list.Where(c => c.Violation))
            if (_reportedViolations.TryAdd($"{c.FromHost}|{c.ToHost}", 0))
                store.Log(s, Severity.CRITICAL, "ENV-CROSS",
                    $"{c.FromName} ({c.FromEnv}) is connected to {c.ToHost}{(c.ToPort is int p ? ":" + p : "")} ({c.ToEnv}). {c.FromEnv} services must only use {c.FromEnv} endpoints.");
    }
}
