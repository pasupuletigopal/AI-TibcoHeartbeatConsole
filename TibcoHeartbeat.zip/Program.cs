using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.DataProtection;
using TibcoHeartbeat;
using TibcoHeartbeat.Probes;

var builder = WebApplication.CreateBuilder(args);
var dataDir = builder.Configuration["DataDir"] ?? Path.Combine(AppContext.BaseDirectory, "data");

builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddDataProtection().PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(dataDir, "keys")));
builder.Services.AddHttpClient("probe", c => c.Timeout = TimeSpan.FromSeconds(8))
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        // Internal TIBCO endpoints often use self-signed certificates. Set Probe:AllowInvalidCertificates=false in production.
        ServerCertificateCustomValidationCallback = builder.Configuration.GetValue("Probe:AllowInvalidCertificates", true)
            ? HttpClientHandler.DangerousAcceptAnyServerCertificateValidator : null
    });
builder.Services.AddSingleton<Store>();
builder.Services.AddSingleton<IProbe, EmsProbe>();
builder.Services.AddSingleton<IProbe, Bw6Probe>();
builder.Services.AddSingleton<IProbe, BwceProbe>();
builder.Services.AddSingleton<IProbe, HawkProbe>();
builder.Services.AddSingleton<Poller>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<Poller>());

var app = builder.Build();
ProbeHelpers.DegradedAfterMs = app.Configuration.GetValue("Probe:DegradedAfterMs", 1500);

app.UseDefaultFiles();
app.UseStaticFiles();

var api = app.MapGroup("/api");

api.MapGet("/ping", () => new { service = "TibcoHeartbeat", version = "1.0", time = DateTimeOffset.UtcNow });

// ---- servers CRUD ----
static ServerConfig Public(ServerConfig s) => new()
{
    Id = s.Id, Name = s.Name, Type = s.Type, Env = s.Env, Host = s.Host, Port = s.Port, Protocol = s.Protocol,
    Username = s.Username, ProtectedPassword = s.ProtectedPassword is null ? null : "set", Domain = s.Domain,
    HealthPath = s.HealthPath, PollSeconds = s.PollSeconds, Enabled = s.Enabled, Downstream = s.Downstream, Notes = s.Notes
};

Dictionary<string, string[]> Validate(ServerConfig s, Store store, string? id)
{
    var e = new Dictionary<string, string[]>();
    if (string.IsNullOrWhiteSpace(s.Name)) e["name"] = ["Name is required."];
    else if (store.Servers.Any(x => x.Id != id && x.Name.Equals(s.Name.Trim(), StringComparison.OrdinalIgnoreCase))) e["name"] = ["Another server already uses this name."];
    if (!Regex.IsMatch(s.Host ?? "", @"^[A-Za-z0-9.\-_]+$")) e["host"] = ["Host must be a host name or IP address."];
    if (s.Port is < 1 or > 65535) e["port"] = ["Port must be between 1 and 65535."];
    if (!new[] { "DEV", "QA", "UAT", "PROD" }.Contains(s.Env?.ToUpperInvariant())) e["env"] = ["Env must be DEV, QA, UAT or PROD."];
    if (s.Type == ServerType.BW6 && string.IsNullOrWhiteSpace(s.Domain)) e["domain"] = ["BW6 servers need a domain."];
    var bad = s.Downstream?.FirstOrDefault(d => !Regex.IsMatch(d, @"^[A-Za-z0-9.\-_]+:\d{1,5}$"));
    if (bad != null) e["downstream"] = [$"'{bad}' is not host:port."];
    return e;
}

api.MapGet("/servers", (Store store) => store.Servers.Select(Public));

api.MapPost("/servers", async (ServerConfig s, Store store, Poller poller) =>
{
    var errors = Validate(s, store, null);
    if (errors.Count > 0) return Results.ValidationProblem(errors);
    s.Id = "";
    var saved = store.Upsert(s);
    store.Log(saved, Severity.INFO, "CONFIG", $"Server {saved.Name} added ({saved.Type}, {saved.Env})");
    if (saved.Enabled) await poller.CheckAsync(saved.Id, CancellationToken.None);
    return Results.Created($"/api/servers/{saved.Id}", Public(saved));
});

api.MapPut("/servers/{id}", (string id, ServerConfig s, Store store) =>
{
    if (store.Get(id) is null) return Results.NotFound();
    var errors = Validate(s, store, id);
    if (errors.Count > 0) return Results.ValidationProblem(errors);
    s.Id = id;
    var saved = store.Upsert(s);
    store.Log(saved, Severity.INFO, "CONFIG", $"Server {saved.Name} updated");
    return Results.Ok(Public(saved));
});

api.MapDelete("/servers/{id}", (string id, Store store) =>
{
    var s = store.Get(id);
    if (s is null || !store.Delete(id)) return Results.NotFound();
    store.Log(null, Severity.INFO, "CONFIG", $"Server {s.Name} ({s.Host}:{s.Port}) deleted");
    return Results.NoContent();
});

api.MapPost("/servers/{id}/check", async (string id, Store store, Poller poller) =>
{
    if (store.Get(id) is null) return Results.NotFound();
    await poller.CheckAsync(id, CancellationToken.None);
    return Results.Ok(store.Latest(id));
});

// ---- status, logs, connections ----
api.MapGet("/status", (Store store) => store.Status());

api.MapGet("/logs", (Store store, int? take, string? serverId, Severity? minSeverity) =>
    store.Logs(Math.Clamp(take ?? 500, 1, 5000), serverId, minSeverity));

api.MapPost("/logs/ack", (AckRequest req, Store store) => Results.Ok(new { acknowledged = store.Ack(req.Ids ?? new()) }));

api.MapGet("/connections", (Store store) => store.Connections());

api.MapGet("/env-rules", (Store store) => store.Rules);
api.MapPut("/env-rules", (List<EnvRule> rules, Store store) => { store.SaveRules(rules); return Results.Ok(store.Rules); });

app.Run();
