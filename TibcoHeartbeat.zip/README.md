# TibcoHeartbeat

Heartbeat and triage dashboard for TIBCO EMS, BusinessWorks 6, BWCE and Hawk, with a DEV/QA/UAT/PROD isolation check.
One .NET 8 service: it polls your servers, keeps history and logs, and serves the dashboard from `wwwroot`.

## Run

```bash
dotnet run -c Release          # http://localhost:5080
```

Open the page, click **Add server**, enter the details. No packages beyond the .NET 8 SDK are needed.
Data is stored in `data/` (`servers.json`, `env-rules.json`, daily `logs/heartbeat-YYYYMMDD.jsonl`).
Passwords are encrypted with ASP.NET Data Protection (keys in `data/keys`) and never returned by the API.

If `index.html` is opened without the service it runs in demo mode with simulated servers.

## What each probe checks

| Type | Check | Healthy | Degraded |
|------|-------|---------|----------|
| EMS  | TCP connect to host:port | port open | slower than `Probe:DegradedAfterMs` |
| EMS + admin API | server state, client connections, routes | active, routes connected | any route disconnected |
| BW6  | `GET /bw/v1/browse/appnodes?domain=` and `/applications?domain=` on the bwagent (8079) | all AppNodes and apps Running | an AppNode not Running or an app Impaired |
| BWCE | `GET /_ping` on 7777 (or your health path) | HTTP 2xx | slow |
| Hawk | TCP connect, or HTTP GET if protocol is http/https | reachable | slow |

Give the bwagent a read-only user (`user` role in `realm.properties`) for monitoring.

## Reading EMS connections and routes (upstream / downstream)

Without the admin API, EMS is a liveness check only. To get the live client list and routes:

1. Copy `TIBCO.EMS.ADMIN.dll` and `TIBCO.EMS.dll` from your EMS install into `lib/`.
2. In `TibcoHeartbeat.csproj`, uncomment the `ItemGroup` and add `<DefineConstants>$(DefineConstants);EMS_ADMIN</DefineConstants>`.
3. Build. If a member name does not match your EMS version, fix it in `Probes/Probes.cs` (`ReadAdmin`), using the admin API reference that ships with EMS.

## Environment check

Every link (declared downstream endpoints, EMS clients, EMS routes) gets an environment on both ends:
a registered server's host uses that server's env; any other host is matched by name parts against the rules
(`ems-dev-01.corp.local` has the part `dev`, so rule `dev -> DEV` applies; trailing digits are ignored).
Links between two different environments raise a CRITICAL `ENV-CROSS` log line once, and show in the Connections tab.

## API

| Method | Path | |
|---|---|---|
| GET | /api/ping | service check (the dashboard uses it to switch to live mode) |
| GET, POST | /api/servers | list, add |
| PUT, DELETE | /api/servers/{id} | edit, delete |
| POST | /api/servers/{id}/check | check now |
| GET | /api/status | last 60 heartbeats per server |
| GET | /api/logs?take=&serverId=&minSeverity= | newest first |
| POST | /api/logs/ack | `{ "ids": [...] }` |
| GET | /api/connections | links with env and violation flag |
| GET, PUT | /api/env-rules | host-part to environment rules |

## Settings (appsettings.json)

`Urls`, `DataDir`, `Probe:DegradedAfterMs` (default 1500), `Probe:AllowInvalidCertificates`
(default true for self-signed internal certs; set false in production).

Put the service behind your normal SSO or reverse proxy: the API has no authentication of its own.
