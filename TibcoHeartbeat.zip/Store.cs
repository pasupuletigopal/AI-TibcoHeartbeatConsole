using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.DataProtection;

namespace TibcoHeartbeat;

/// <summary>
/// Servers and environment rules are persisted as JSON under DataDir.
/// Heartbeat history and logs live in memory (ring buffers); logs are also appended to daily .jsonl files.
/// </summary>
public class Store
{
    public const int HistoryLength = 60;
    const int MaxLogs = 5000;

    readonly string _dir;
    readonly IDataProtector _protector;
    readonly object _lock = new();
    readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web) { WriteIndented = true, Converters = { new JsonStringEnumConverter() } };

    List<StoredServer> _servers = new();
    List<EnvRule> _rules = new();
    readonly ConcurrentDictionary<string, List<Heartbeat>> _history = new();
    readonly LinkedList<LogEntry> _logs = new();
    readonly ConcurrentDictionary<string, List<Connection>> _conns = new();

    public Store(IConfiguration cfg, IDataProtectionProvider dp)
    {
        _dir = cfg["DataDir"] ?? Path.Combine(AppContext.BaseDirectory, "data");
        Directory.CreateDirectory(_dir);
        Directory.CreateDirectory(Path.Combine(_dir, "logs"));
        _protector = dp.CreateProtector("TibcoHeartbeat.ServerPasswords");
        _servers = Load<List<StoredServer>>("servers.json") ?? new();
        _rules = Load<List<EnvRule>>("env-rules.json") ?? new()
        {
            new("dev","DEV"), new("qa","QA"), new("test","QA"), new("uat","UAT"), new("prod","PROD"), new("prd","PROD")
        };
    }

    T? Load<T>(string file)
    {
        var p = Path.Combine(_dir, file);
        return File.Exists(p) ? JsonSerializer.Deserialize<T>(File.ReadAllText(p), _json) : default;
    }
    void Save<T>(string file, T value)
    {
        var p = Path.Combine(_dir, file);
        File.WriteAllText(p + ".tmp", JsonSerializer.Serialize(value, _json));
        File.Move(p + ".tmp", p, true);
    }

    // ---------- servers ----------
    public IReadOnlyList<ServerConfig> Servers { get { lock (_lock) return _servers.ToList(); } }
    public ServerConfig? Get(string id) { lock (_lock) return _servers.FirstOrDefault(s => s.Id == id); }

    public string? DecryptPassword(ServerConfig s) =>
        string.IsNullOrEmpty(s.ProtectedPassword) ? null : _protector.Unprotect(s.ProtectedPassword);

    public ServerConfig Upsert(ServerConfig input)
    {
        lock (_lock)
        {
            var existing = _servers.FirstOrDefault(s => s.Id == input.Id);
            var target = existing ?? new StoredServer { Id = Guid.NewGuid().ToString("N")[..12] };
            target.Name = input.Name.Trim(); target.Type = input.Type; target.Env = input.Env.ToUpperInvariant();
            target.Host = input.Host.Trim(); target.Port = input.Port; target.Protocol = input.Protocol.ToLowerInvariant();
            target.Username = input.Username; target.Domain = input.Domain; target.HealthPath = input.HealthPath;
            target.PollSeconds = Math.Clamp(input.PollSeconds, 5, 3600); target.Enabled = input.Enabled;
            target.Downstream = input.Downstream; target.Notes = input.Notes;
            if (!string.IsNullOrEmpty(input.Password)) target.ProtectedPassword = _protector.Protect(input.Password);
            if (existing is null) _servers.Add(target);
            Save("servers.json", _servers);
            return target;
        }
    }

    public bool Delete(string id)
    {
        lock (_lock)
        {
            var n = _servers.RemoveAll(s => s.Id == id);
            if (n > 0) { Save("servers.json", _servers); _history.TryRemove(id, out _); _conns.TryRemove(id, out _); }
            return n > 0;
        }
    }

    // ---------- env rules ----------
    public IReadOnlyList<EnvRule> Rules { get { lock (_lock) return _rules.ToList(); } }
    public void SaveRules(List<EnvRule> rules)
    {
        lock (_lock) { _rules = rules.Where(r => !string.IsNullOrWhiteSpace(r.Token)).Select(r => r with { Token = r.Token.Trim().ToLowerInvariant(), Env = r.Env.ToUpperInvariant() }).ToList(); Save("env-rules.json", _rules); }
    }

    /// <summary>Registered hosts use their own env; otherwise match host name parts (trailing digits ignored).</summary>
    public string EnvOfHost(string host)
    {
        var h = host.Split(':')[0].Trim().ToLowerInvariant();
        var reg = Servers.FirstOrDefault(s => s.Host.Equals(h, StringComparison.OrdinalIgnoreCase));
        if (reg != null) return reg.Env;
        var tokens = h.Split('.', '-', '_').Select(t => t.TrimEnd('0','1','2','3','4','5','6','7','8','9')).ToHashSet();
        foreach (var r in Rules) if (tokens.Contains(r.Token)) return r.Env;
        return "UNKNOWN";
    }

    // ---------- heartbeats ----------
    public Heartbeat? Latest(string id) => _history.TryGetValue(id, out var h) ? h.LastOrDefault() : null;
    public void AddHeartbeat(string id, Heartbeat hb)
    {
        var list = _history.GetOrAdd(id, _ => new());
        lock (list) { list.Add(hb); if (list.Count > HistoryLength) list.RemoveAt(0); }
    }
    public object Status() => Servers.Select(s =>
    {
        var h = _history.TryGetValue(s.Id, out var l) ? l : new();
        lock (h) return new { serverId = s.Id, history = h.ToList() };
    }).ToList();

    // ---------- logs ----------
    public LogEntry Log(ServerConfig? s, Severity sev, string code, string message)
    {
        var e = new LogEntry { ServerId = s?.Id, ServerName = s?.Name ?? "collector", Severity = sev, Code = code, Message = message };
        lock (_logs) { _logs.AddFirst(e); while (_logs.Count > MaxLogs) _logs.RemoveLast(); }
        try
        {
            File.AppendAllText(Path.Combine(_dir, "logs", $"heartbeat-{e.Ts:yyyyMMdd}.jsonl"),
                JsonSerializer.Serialize(e, _json).ReplaceLineEndings("") + Environment.NewLine);
        }
        catch { /* file logging is best effort */ }
        return e;
    }
    public List<LogEntry> Logs(int take, string? serverId, Severity? minSev)
    {
        lock (_logs) return _logs.Where(l => (serverId == null || l.ServerId == serverId) && (minSev == null || l.Severity <= minSev))
                                  .Take(take).ToList();
    }
    public int Ack(IEnumerable<string> ids)
    {
        var set = ids.ToHashSet(); var n = 0;
        lock (_logs) foreach (var l in _logs) if (!l.Acked && set.Contains(l.Id)) { l.Acked = true; n++; }
        return n;
    }

    // ---------- connections ----------
    public void SetConnections(string serverId, List<Connection> conns) => _conns[serverId] = conns;
    public List<Connection> Connections() => _conns.Values.SelectMany(c => c).ToList();
}
